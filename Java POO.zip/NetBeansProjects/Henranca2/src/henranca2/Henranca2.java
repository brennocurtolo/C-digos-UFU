package henranca2;

public class Henranca2 {

    public static void main(String[] args) {
       //Pessoa p1 = new Pessoa(); NAO TEM COMO INSTANCIAR UM OBJETO DE UMA CLASSE ABSTRACT
       
       Visitante v1 = new Visitante();
       v1.setNome("Joao");
       v1.setIdade(20);
       v1.setSexo("M");
       
       Aluno a1 = new Aluno();
       a1.setNome("Maria");
       a1.setIdade(17);
       a1.setSexo("F");
       a1.setMatricula(2020);
       a1.setCurso("RI");
       a1.pagarMensalidade();
       
       Bolsista b1 = new Bolsista();
       b1.setMatricula(1919);
       b1.setNome("Pedro");
       b1.setBolsa(1250.20f);
       b1.pagarMensalidade();
       
       
       
       System.out.println(v1.toString());
       
    }
    
}
