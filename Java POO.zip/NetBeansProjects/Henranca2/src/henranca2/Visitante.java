package henranca2;

public class Visitante extends Pessoa {
    
}
