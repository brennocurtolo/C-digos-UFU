package henranca2;

public class Aluno extends Pessoa {
    private int matricula;
    private String curso;
    
    public void pagarMensalidade(){ //Se colocar public final void pagarMensalidade() (Método final) essa função nao pode ser sobreposta
        System.out.println("Pagamento da mensalidade do aluno: "+ this.getNome());
        
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }
              
}
