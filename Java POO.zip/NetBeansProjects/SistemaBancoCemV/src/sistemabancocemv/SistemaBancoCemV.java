package sistemabancocemv;

public class SistemaBancoCemV {

    public static void main(String[] args) {
        Conta c1 = new Conta();
        c1.setNumConta(1111);
        c1.setNome("Brenno");
        c1.abrirConta("CC");
        c1.depositar(100);
        
        
        
        Conta c2 = new Conta();
        c2.setNumConta(2222);
        c2.setNome("Maria");
        c2.abrirConta("CP");
        c2.depositar(500);
        c2.sacar(25.50f);
        
        
        c1.estadoAtual();
        c2.estadoAtual();
        
    }
    
}
