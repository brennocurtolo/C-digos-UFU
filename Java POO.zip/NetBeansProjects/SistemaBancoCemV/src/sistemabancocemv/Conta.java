package sistemabancocemv;

public class Conta {
    
    //Atributos
    protected String tipo, nome;
    private boolean status;
    private float saldo;
    public int numConta;
    
    //Construtor
    public void Construtor(float s, boolean sta){
       this.saldo = 0; //OU this.setSaldo(0);
       this.setStatus(false); //OU this.status = false;
    }
    
    //Métodos personalizados
    
    public void estadoAtual(){
        System.out.println("--------Contas--------");
        System.out.println("Conta: " + this.getNumConta());
        System.out.println("Tipo: " + this.getTipo());
        System.out.println("Nome: " + this.getNome());
        System.out.println("Saldo: " + this.getSaldo());
        System.out.println("Status: " + this.getStatus());
    }
    
    public void abrirConta(String t){
        this.setTipo(t); //'t' será setado como cp (conta poupança) ou cc (conta corrente) pelo usuário
        this.setStatus(true);    //OU this.status = true;
        
        if (t == "CC"){
            this.setSaldo(50);
        }
        else if (t == "CP"){
            this.setSaldo(150.0f);
        }
        System.out.println("Conta aberta com sucesso.");
    }
    
    public void fecharConta(){
        if (this.getSaldo() < 0){
            System.out.println("Erro: Saldo negativo. ");
        }
        if (this.getSaldo() > 0){
            System.out.println("Erro: Saldo positivo. ");
        }
        else{
            this.setStatus(false);    //OU this.status = false;
            System.out.println("Conta fechada com sucesso.");
        }
        
    }
    
    public void depositar(float s){
        if (this.getStatus()){
            this.setSaldo(this.getSaldo() + s); //OU this.saldo += s;
            System.out.println("Deposito realizado");
        }
        else{
            System.out.println("Erro: conta nao foi aberta. ");
        }
    }
    
    public void sacar(float s){
        if (this.getStatus()){
           if (this.getSaldo() >= s){
               this.setSaldo(this.getSaldo() - s);
               System.out.println("Saldo realizado na conta de: " + this.getNome());
           }
           else{
               System.out.println("Saldo insuficiente.");
           }
        }
        else{
            System.out.println("A conta nao esta aberta.");
        }
    }
    
    public void pagarMensal(){
        int v = 0;
        if (this.getTipo() == "CC") {
            v = 12;
        } else if (this.getTipo() == "CP"){
            v = 20;
        }
        if (this.getStatus()){
            this.setSaldo(this.getSaldo() - v);
        }
        else{
            System.out.println("A conta nao esta aberta.");
        }
        
    }
    
    //Métodos especiais
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getNome(){
        return nome;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    public boolean getStatus() {    //metodos que usam boolean retornam "is", por exemplo isStatus()
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    public int getNumConta() {
        return numConta;
    }

    public void setNumConta(int numConta) {
        this.numConta = numConta;
    }
}
