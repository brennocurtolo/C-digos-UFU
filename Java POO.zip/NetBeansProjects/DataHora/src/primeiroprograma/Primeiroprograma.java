package primeiroprograma;

import java.util.Date;

public class Primeiroprograma {

    public static void main(String[] args) {
        Date relogio = new Date();     //new (criar novo objeto)
        System.out.println("A hora do sistema eh: ");
        System.out.println(relogio.toString()); //converte o objeto data para uma string
    }
    
}
