package exerciciopraticocemv;

public class ExercicioPraticoCemV {

    public static void main(String[] args) {
        Pessoa[] p = new Pessoa[2];
        Livro[] l = new Livro[3];
        
        p[0] = new Pessoa("Brenno", "Masculino", 20);
        p[1] = new Pessoa("Maria", "Feminino", 22);
        
        l[0] = new Livro("Adeus", "Marcelo Soares", 200, p[0]);
        l[1] = new Livro("A face", "Fernanda Monte", 300, p[1]);
        l[2] = new Livro("Mais um", "Fatima da Silva", 600, p[1]);
        
        l[0].abrir();
        l[0].folhear(140);
        l[0].avançarPag();
        
        System.out.println(l[0].detalhes() + "\n");
        
        System.out.println(l[1].detalhes());
    }
    
}
