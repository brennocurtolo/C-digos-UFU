package linguagemsistema;

public class Linguagemsistema {

    public static void main(String[] args) {
        System.out.println("O sistema esta em: ");
        System.getProperties ();
        System.out.println(System.getProperty("user.language"));
    }
}
    
