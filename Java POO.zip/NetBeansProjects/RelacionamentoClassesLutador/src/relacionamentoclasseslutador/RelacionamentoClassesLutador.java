package relacionamentoclasseslutador;

public class RelacionamentoClassesLutador {

    public static void main(String[] args) {
        Lutador l[] = new Lutador[6];
        
        l[0] = new Lutador("Brenno", "Brasil", 1.75f, 85.5f, 20, 10, 3, 2);
        
        l[1] = new Lutador("Fernando", "Brasil", 1.80f, 90.5f, 22, 4, 3, 3);
        
        Luta a1 = new Luta();
        a1.marcarLuta(l[0], l[1]);
        a1.lutar();
        
        
        l[0].status();
        l[1].status();
        
        
        
        
        //l[0].apresentar();
        //l[0].status();
        //l[1].apresentar();
        //l[1].status();
    
    }
    
}
