package relacionamentoclasseslutador;

import java.util.Random;

public class Luta {
    //Atributos
    private Lutador desafiado, desafiante;
    private int rounds;
    private boolean aprovada;
    
    //Métodos
    public void marcarLuta(Lutador p1, Lutador p2){
        if (p1.getCategoria().equals(p2.getCategoria()) && (p1 != p2)){
            this.setAprovada(true);
            this.setDesafiado(p1);
            this.setDesafiante(p2);
        } else{
            this.aprovada = false;
            this.desafiado = null;
            this.desafiante = null;
        }
        
    }
    
    public void lutar (){
        if (this.getAprovada()){
            System.out.println("---LUTA ENTRE---");
            this.desafiado.apresentar();
            this.desafiante.apresentar();
            
            Random aleatorio = new Random();    //Criar um número aleatório
            int vencedor = aleatorio.nextInt(3);    //irá gerar 0, 1 ou 2
            switch(vencedor){
                
                case 0 -> {
                    //Empate
                    System.out.println("Empate");
                    this.desafiado.empatarLuta();
                    this.desafiante.empatarLuta();
                }
                    
                case 1 -> {
                    //Desafiado vence
                    System.out.println("Venceu: "+ this.desafiado.getNome());
                    this.desafiado.ganharLuta();
                    this.desafiante.perderLuta();
                }
                    
                case 2 -> {
                    //Desafiante vence
                    System.out.println("Venceu: "+ this.desafiante.getNome());
                    this.desafiado.perderLuta();
                    this.desafiante.ganharLuta();
                }
                
            }
            
        }else{
            System.out.println("A luta nao pode acontecer.");
        }
        
    }
    
    //Métodos especiais

    public Lutador getDesafiado() {
        return desafiado;
    }

    public void setDesafiado(Lutador desafiado) {
        this.desafiado = desafiado;
    }

    public Lutador getDesafiante() {
        return desafiante;
    }

    public void setDesafiante(Lutador desafiante) {
        this.desafiante = desafiante;
    }

    public int getRounds() {
        return rounds;
    }

    public void setRounds(int rounds) {
        this.rounds = rounds;
    }

    public boolean getAprovada() {
        return aprovada;
    }

    public void setAprovada(boolean aprovada) {
        this.aprovada = aprovada;
    }
    
    
    
}
