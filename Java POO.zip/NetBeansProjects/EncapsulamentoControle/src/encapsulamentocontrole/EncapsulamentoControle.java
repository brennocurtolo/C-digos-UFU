package encapsulamentocontrole;

public class EncapsulamentoControle {

    public static void main(String[] args) {
        ControleRemoto c1 = new ControleRemoto();
        c1.ligar();
        c1.maisVolume();
        
        c1.abrirMenu();
        
    }
    
}
