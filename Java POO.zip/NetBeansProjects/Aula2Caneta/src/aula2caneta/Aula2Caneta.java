package aula2caneta;

public class Aula2Caneta {

    public static void main(String[] args) {
        
        System.out.println("--Canetas--"); 
        System.out.println("");
        System.out.println("Caneta 1"); 
        
        Caneta c1 = new Caneta();
        c1.cor = "azul";
        c1.ponta = 0.5f;
        c1.modelo = "BIC cristal";
        c1.carga = 80;
        //c1.destampar();
        //c1.statusdacaneta();
        //c1.rabiscar();
        
        System.out.println(""); 
        System.out.println("Caneta 2"); 
        
        Aula3visibilidade c2 = new Aula3visibilidade();
        c2.cor = "preta";
        c2.ponta = 1f;
        c2.modelo = "BIC normal";
        c2.carga = 100;
        c2.tampar();
        c2.statusdacaneta2();
        c2.rabiscar();
    }
    
}
