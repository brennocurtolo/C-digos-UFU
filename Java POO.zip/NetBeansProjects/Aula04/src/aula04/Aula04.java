package aula04;

public class Aula04 {
    
    public static void main(String[] args) {
        Caneta c1 = new Caneta("NICK", "vermelho", 0.4f); //chamada do metodo construtor
        
        //c1.setModelo("BIC"); //Método acessor
        //c1.modelo = "BIC";  //Acesso direto ao atributo (funciona porque é publico)
        
        //c1.setPonta(0.5f); //Método acessor
        //c1.ponta = 0.5f;    //Acesso direto ao atributo (Não funciona porque é privado)
        
        System.out.println("--Canetas--");
        System.out.println("");
        
        System.out.println("Caneta 1");
        System.out.println("Modelo: "+ c1.getModelo());
        System.out.println("Ponta: "+ c1.getPonta());
        System.out.println("Cor: "+ c1.getCor());
        System.out.println("Tampada: "+ c1.getTampada());
        
        //c1.status();
        
        Caneta c2 = new Caneta("BIC", "amarela", 0.3f);
        
        System.out.println("");
        System.out.println("Caneta 2");
        c2.status();
    }
    
}
