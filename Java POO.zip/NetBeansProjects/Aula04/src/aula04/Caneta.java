package aula04;

public class Caneta {
    public String modelo;
    private float ponta;
    private boolean tampada;
    private String cor;
    
        //public Caneta(){ //Método construtor simples (mesmo nome da classe)
    //    this.tampar();
    //    this.getCor();
        //this.cor = "azul";
    //}
    
     public Caneta(String m, String c, float p){ //Método construtor complexo (mesmo nome da classe)
        this.setModelo(m);
        this.setPonta(p);
        this.tampar();
        this.setCor(c);
        //this.cor = "azul";
    }
    
    public void tampar(){
        this.tampada = true;
    }
    
    public void destampar(){
        this.tampada = false;
    }
    
    public String getModelo(){
        return this.modelo;
    }
    
    public void setModelo(String m){
        this.modelo = m;
    }
    
    public float getPonta(){
        return this.ponta;
    }
    
    public void setPonta(float p){
        this.ponta = p;
    }
    
    public String getCor(){
        return this.cor;
    }
    
    public void setCor(String c){
        this.cor = c;
    }
    
    public boolean getTampada(){
        return this.tampada;
    }
    
    public void status(){
        System.out.println("--Canetas--");
        System.out.println("Modelo: "+ this.getModelo());
        System.out.println("Ponta: "+ this.getPonta());
        System.out.println("Cor: "+ this.getCor());
        System.out.println("Tampada: "+ this.getTampada());
    }

}
