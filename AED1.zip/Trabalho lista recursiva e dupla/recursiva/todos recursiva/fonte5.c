/*
    Avaliativa: Lista Din�mica/Encadeada

    Por Brenno Cavalcanti 2021.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fonte5.h"

struct no{
    int info;
    char sstring[10];
    struct no* prox;
};

/*
    Opera��o Cria_lista:

    -Entrada: nenhuma

    -Pr�-condi��o: nenhuma

    -Processo: nenhuma

    -Sa�da: endere�o nulo

    -P�s-condi��o: nenhuma
*/

lista cria_lista (){

    return NULL;
}

/*
    Opera��o lista_vazia:

    -Entrada: endere�o de uma lista

    -Pr�-condi��o: nenhuma

    -Processo: verifica se a lista est� vazia

    -Sa�da: 1 se vazia ou 0 caso contr�rio

    -P�s-condi��o: nenhuma
*/

int lista_vazia (lista li){
    if (li == NULL)
        return 1;

    else
        return 0;
}

/*
    Opera��o insere_ord:

    -Entrada: endere�o do endere�o de uma lista, string a ser colocada

    -Pr�-condi��o: nenhuma

    -Processo: alocar um n� e alterar o valor do elemento pelo par�metro passado, adicionar no in�cio da lista esse n�

    -Sa�da: 1 se inseriu o elemento ou 0 caso contr�rio

    -P�s-condi��o: lista com mais um n�
*/

//Inserir elemento de forma ordenada

int insere_ord(lista* li, char sstring[]){

    lista li2 = (lista) malloc(sizeof(struct no));                                    //aloca��o para uma struct no_aluno

    if (li2 == NULL)
        return 0;

    strcpy(li2 -> sstring, sstring);

    if (lista_vazia(*li) || strcmp (sstring, (*li) -> sstring) <= 0){            // <=

        li2 -> prox = *li;                              //aponta para o 1� no atual da lista (ja existente)
        *li = li2;                                      //faz a lista apontar para o novo no

        return 1;
    }

     /*lista aux = *li;                                   //aux aponta para o primeiro no
     while (aux -> prox != NULL && strcmp(sstring, aux -> prox -> sstring) > 0)      // >
        aux = aux -> prox;

     li2 -> prox = aux -> prox;
     aux -> prox = li2;
    */
     else{

        return insere_ord (&((*li) -> prox), sstring);
     }

}

/*
    Opera��o remove_ord:

    -Entrada: endere�o do endere�o de uma lista, string a ser colocada

    -Pr�-condi��o: lista nao ser vazia

    -Processo: percorrer a lista ate encontrar o elemento que deseja remover e depois remove-lo

    -Sa�da: 1 se remove o elemento ou 0 caso contr�rio

    -P�s-condi��o: lista com menos um n�
*/
//Remove de forma ordenada

int remove_ord (lista* li, char sstring[]){

    if (lista_vazia (*li) == 1)
        return 0;

    lista aux = *li;

    //while (aux -> prox != NULL && (strcmp(aux -> prox -> sstring, sstring)) < 0)     // <   < 0
            //aux = aux -> prox;


    if (aux -> prox == NULL || (strcmp(aux -> prox -> sstring, sstring)) > 0){       // >    > 0

        if (strcmp (aux -> sstring, sstring) == 0){
            lista aux2 = aux -> prox;
            aux -> prox = NULL;
            *li = aux2;
            free(aux);
            return 1;
        }
        else
            return 0;
    }

    else{

        return remove_ord (&((*li) -> prox), sstring);
     }

}
/*
    Opera��o esvazia_lista:

    -Entrada: endere�o do endere�o de uma lista

    -Pr�-condi��o: lista n�o estar vazia

    -Processo: esvaziar a lista, at� a mesma ficar vazia

    -Sa�da: 1 caso tenha esvaziado a lista ou 0 caso o contr�rio

    -P�s-condi��o: lista vazia
*/
int esvazia_lista (lista* li){
    if (*li == NULL)
        return 0;

    while (*li != NULL){

        lista aux = *li;
        *li = aux -> prox;
        free(aux);

    }
    return 1;
}
/*
    Opera��o apaga_lista:

    -Entrada: endere�o do endere�o de uma lista

    -Pr�-condi��o: nenhuma

    -Processo: retornar a fun��o esvazia_lista

    -Sa�da: esvazia_lista

    -P�s-condi��o: lista vazia
*/
int apaga_lista (lista* li){

    return (esvazia_lista(li));
}
/*
    Opera��o get_elem_pos:

    -Entrada: endere�o de uma lista, uma vari�vel inteira pos (Posi��o desejada) e o endere�o de uma string

    -Pr�-condi��o: A lista n�o estar vazia e a posi��o pos ser maior ou igual a 1

    -Processo: Percorre a lista at� chegar na posi��o desejada e adiciona a informa��o do n� encontrado na vari�vel de string

    -Sa�da: 1 para sucesso e 0 para falha

    -P�s-condi��o: nenhuma
*/
int get_elem_pos(lista li, int pos, int* info, char sstring[]){               //li (n�o passa por referencia pois a lista n�o � alterada em momento nenhum, so estou pegando os elementos)

    if (lista_vazia (li) == 1 || pos <= 0)
        return 0;

    int cont = 1;                                                              //se a lista n�o � vazia come�a-se o contador com 1
    lista aux = li;

     while (aux->prox != NULL && cont < pos)
    {
        aux = aux->prox;
        cont++;
    }

    if (cont != pos)
        return 0;

    strcpy (sstring, aux -> sstring);
    *info = li -> info;

    return 1;
}














