/*
    Avaliativa: Lista Din�mica/Encadeada

    Por Brenno Cavalcanti 2021.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fonte4.h"

struct no{
    int info;
    char sstring[10];
    struct no* prox;
};

lista cria_lista (){
    lista cab;
    cab = (lista) malloc(sizeof(struct no));

    if (cab != NULL){
        cab -> prox = NULL;
    }

    return cab;
}

int lista_vazia (lista li){
    if (li -> prox == NULL)
        return 1;

    else
        return 0;
}

//Inserir elemento de forma ordenada

int insere_ord(lista* li, char sstring[]){

    lista li2 = (lista) malloc(sizeof(struct no));                                    //aloca��o para uma struct no_aluno

    if (li2 == NULL)
        return 0;

    strcpy(li2 -> sstring, sstring);

    if (lista_vazia(*li) || strcmp (sstring, (*li) -> sstring) <= 0){            // <=

        li2 -> prox = *li;                              //aponta para o 1� no atual da lista (ja existente)
        *li = li2;                                      //faz a lista apontar para o novo no

        return 1;
    }

     lista aux = *li;                                   //aux aponta para o primeiro no
     while (aux -> prox != NULL && strcmp(sstring, aux -> prox -> sstring) > 0)      // >
        aux = aux -> prox;

     li2 -> prox = aux -> prox;
     aux -> prox = li2;

     return 1;
}


//Remove de forma ordenada

int remove_ord (lista* li, char sstring[]){

    if (lista_vazia (*li) == 1)
        return 0;

    lista aux = *li;

    while (aux -> prox != NULL && (strcmp(aux -> prox -> sstring, sstring)) < 0)     // <   < 0
            aux = aux -> prox;

    if (aux -> prox == NULL || (strcmp(aux -> prox -> sstring, sstring)) > 0)         // >    > 0
        return 0;

    lista aux2 = aux -> prox;
    aux -> prox =  aux2 -> prox;
    free(aux2);

    return 1;
}

int esvazia_lista (lista* li){
    if (*li == NULL)
        return 0;

    while (*li != NULL){

        lista aux = *li;
        *li = aux -> prox;
        free(aux);

    }
    return 1;
}

int apaga_lista (lista* li){

    return (esvazia_lista(li));
}

int get_elem_pos(lista li, int pos, int info, char sstring[]){               //li (n�o passa por referencia pois a lista n�o � alterada em momento nenhum, so estou pegando os elementos)

    if (lista_vazia (li) == 1 || pos <= 0)
        return 0;

    int cont = 1;                                                              //se a lista n�o � vazia come�a-se o contador com 1
    lista aux = li;

     while (aux->prox != NULL && cont < pos)
    {
        aux = aux->prox;
        cont++;
    }

    if (cont != pos)
        return 0;

    strcpy (sstring, aux -> sstring);
    info = li -> info;

    return 1;
}














