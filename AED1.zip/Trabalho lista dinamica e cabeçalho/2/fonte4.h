#ifndef FONTE2_H_INCLUDED
#define FONTE2_H_INCLUDED

typedef struct no* lista;

lista cria_lista ();
int lista_vazia (lista li);
int insere_ord(lista* li, char sstring[]);
int remove_ord (lista* li, char sstring[]);
int get_elem_pos(lista li, int pos, int info, char sstring[]);
int esvazia_lista (lista* li);
int apaga_lista (lista* li);

#endif // FONTE2_H_INCLUDED
