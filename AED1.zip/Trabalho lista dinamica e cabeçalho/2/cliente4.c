#include <stdio.h>
#include <stdlib.h>

#include "fonte4.h"

void imprime(lista li);

int main()
{
    int maximo = 0, n = 0;
    lista li;
    int x;
    char sstring[10];

    while(maximo != 7){

        printf("\n");
        printf(" 1 - Criar uma lista\n");
        printf(" 2 - Inserir uma string na lista\n");
        printf(" 3 - Remover uma string da lista\n");
        printf(" 4 - Imprimir Lista\n");
        printf(" 5 - Limpar Lista\n");
        printf(" 6 - Apagar Lista\n");
        printf(" 7 - Sair\n");
        printf("\n");

        scanf("%d", &n);
        setbuf(stdin, NULL);

        switch(n){
           case 1:
               li = cria_lista();
                if(li == NULL)
                    printf("A lista n�o foi criada!\n");
                else
                    printf("A lista foi criada!\n");
                break;
            case 2:
                printf ("Digite uma palavra com maximo de 10 caracteres:\n");
                scanf("%s", sstring);
                insere_ord(&li, sstring);
                break;
            case 3:
                printf ("Qual palavra deseja remover?\n");
                scanf("%s", sstring);
                remove_ord (&li, sstring);
                break;
            case 4:
                imprime(li);
                break;
            case 5:
                if (esvazia_lista(&li)== 0)
                    printf("Lista inexistente\n");
                else
                    printf("Lista vazia\n");
                break;
            case 6:
                apaga_lista(&li);
                if(li == 0)
                    printf("memoria liberada\n");
                break;
            case 7:
                maximo = 7;
                break;
            default:
                printf("opcao invalida!\n");
        }
    }
    return 0;
}

void imprime(lista li){

    if(lista_vazia(li) == 1){

        printf("\n --Lista Vazia--\n");
    }
    printf("\nLista: ");

    int pos;
    int info;
    char sstring[10];

    for(pos = 1; get_elem_pos(li, pos, info, sstring) == 1; pos++){
        printf(" %s ", sstring);
    }
}
