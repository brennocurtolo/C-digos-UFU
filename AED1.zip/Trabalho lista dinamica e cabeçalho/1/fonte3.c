/*
    Avaliativa: Lista Din�mica/Encadeada

    Por Brenno Cavalcanti 2021.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fonte3.h"

struct no_aluno{
    unsigned int matricula;
    char nome[20];
    float media;
    int faltas;
    struct no_aluno* prox;
};

lista cria_lista (){
    return NULL;
}

int lista_vazia (lista li){
    if (li == NULL)
        return 1;

    else
        return 0;
}

//Inserir elemento de forma ordenada

int insere_ord(lista* li, unsigned int matricula, char nome[], float media, int faltas){

    lista li2 = (lista) malloc(sizeof(struct no_aluno));                                    //aloca��o para uma struct no_aluno

    if (li2 == NULL)
        return 0;

    li2 -> matricula = matricula;
    strcpy(li2 -> nome, nome);
    li2 -> media = media;
    li2 -> faltas = faltas;

    if (lista_vazia(*li) || matricula <= (*li) -> matricula){

        li2 -> prox = *li;                              //aponta para o 1� no atual da lista (ja existente)
        *li = li2;                                      //faz a lista apontar para o novo no

        return 1;
    }

     lista aux = *li;                                   //aux aponta para o primeiro no
     while (aux -> prox != NULL && matricula > aux -> prox -> matricula)
        aux = aux -> prox;

     li2 -> prox = aux -> prox;
     aux -> prox = li2;

     return 1;
}


//Remove de forma ordenada

int remove_ord (lista* li, unsigned int matricula){

    if (lista_vazia (*li) == 1 || matricula < (*li) -> matricula)
        return 0;

    lista aux = *li;

    if (matricula == (*li) -> matricula){

        *li = aux -> prox;
        free (aux);

        return 1;
    }

    while (aux -> prox != NULL && aux -> prox -> matricula < matricula)
            aux = aux -> prox;

    if (aux -> prox == NULL || aux -> prox -> matricula > matricula)
        return 0;

    lista aux2 = aux -> prox;
    aux -> prox =  aux2 -> prox;
    free(aux2);

    return 1;
}

int esvazia_lista (lista* li){
    if (*li == NULL)
        return 0;

    while (*li != NULL){

        lista aux = *li;
        *li = aux -> prox;
        free(aux);

    }
    return 1;
}

int apaga_lista (lista* li){

    return (esvazia_lista(li));
}

int get_elem_pos(lista li, int pos, unsigned int* matricula, char nome[], float* media, int* faltas){               //li (n�o passa por referencia pois a lista n�o � alterada em momento nenhum, so estou pegando os elementos)

    if (lista_vazia (li) == 1 || pos <= 0)
        return 0;

    int cont = 1;                                                              //se a lista n�o � vazia come�a-se o contador com 1
    lista aux = li;

     while (aux->prox != NULL && cont < pos)
    {
        aux = aux->prox;
        cont++;
    }

    if (cont != pos)
        return 0;

    *matricula = aux -> matricula;
    strcpy (nome, aux -> nome);
    *media = aux -> media;
    *faltas = aux -> faltas;

    return 1;
}














