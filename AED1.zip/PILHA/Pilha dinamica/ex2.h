#ifndef PROVA_H_INCLUDED
#define PROVA_H_INCLUDED

typedef struct _funcionarios * pilha;

pilha cria_pilha();

int pilha_vazia(pilha p);

int push(pilha *p, long int matricula, char nome[30], char setor, float salario);

int le_topo(pilha *p, long int *matricula, char nome[30], char *setor, float *salario);

int pop(pilha *p, int matricula);

int tamanho_pilha(pilha p);

int apaga_pilha(pilha *p);

int esvazia_pilha(pilha* p);

#endif // PROVA_H_INCLUDED
