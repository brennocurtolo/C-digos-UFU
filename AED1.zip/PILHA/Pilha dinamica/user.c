#include <stdio.h>
#include <stdlib.h>
#include "ex2.h"

void imprime_topo(pilha p);
void imprime_pilha(pilha p);

int main(){

    pilha p;
    int ativo = 0;
    int n;
    long int matriculas;
    char elem[30], setors;
    float salarios;

    while(ativo != 1){

        printf("--------------------------------------------\n");
        printf("--Pilha--\n");
        printf("\n 1 - Criar Pilha\n");
        printf(" 2 - Inserir elemento na Pilha\n");
        printf(" 3 - Remover elemento da Pilha\n");
        printf(" 4 - Imprimir Pilha\n");
        printf(" 5 - Imprimir topo da Pilha\n");
        printf(" 6 - Limpar Pilha\n");
        printf(" 7 - Apagar Pilha\n");
        printf(" 8 - Verificar tamanho da Pilha\n");
        printf(" 9 - Sair\n");
        printf("--------------------------------------------\n");

        scanf("%d", &n);
        setbuf(stdin, NULL);

        switch(n){

            case 1:
                p = cria_pilha();
                printf("Pilha criada\n");

                break;

            case 2:
                printf("Insira a matricula: ");
                scanf(" %ld", &matriculas);

                printf("Insira o elemento que deseja adicionar: ");
                scanf(" %s", elem);

                printf("Insira o setor: ");
                scanf(" %c", &setors);

                printf("Insira o salario: ");
                scanf("%f", &salarios);

                if(push(&p, matriculas, elem, setors, salarios) == 0)
                    printf("\nNao foi possivel adicionar.\n");
                else
                    printf("O elemento %s foi incluido.\n", elem);

                break;

            case 3:
                printf("\nDigite a matricula: ");
                scanf("%ld", &matriculas);

                if(pop(&p, matriculas) == 0)
                    printf("O elemento %s nao foi encontrado.\n", elem);
                else
                    printf("O elemento %s foi removido.\n", elem);

                break;

            case 4:
                if(p != NULL)
                    imprime_pilha(p);

                else
                    printf("Nao foi possivel imprimir.\n");

                break;

            case 5:
                if(p != NULL)
                {
                    le_topo(&p, &matriculas, elem, &setors, &salarios);
                    printf("matricula: %ld\n", matriculas);
                    printf("nome: %s\n", elem);
                    printf("setor: %c\n", setors);
                    printf("salario: R$%f\n", salarios);
                }
                else
                    printf("Nao foi possivel imprimir\n");

                break;

            case 6:
                if(esvazia_pilha(&p) == 0)
                    printf("Nao existe nenhuma pilha.\n");
                else
                    printf("Pilha esvaziada.\n");

                break;

            case 7:
                apaga_pilha(&p);
                printf("Pilha apagada.\n");

                break;

            case 8:
                if (tamanho_pilha(p) >= 0)
                    printf("A Pilha tem tamanho igual a %d\n", tamanho_pilha(p));
                else
                    printf("Pilha invalida\n");

                break;

            case 9:
                ativo = 1;
                break;

            default:
                printf("opcao invalida!\n");
            }

    }

    return 0;
}

void imprime_pilha(pilha p)
{
    long int matricula;
    char elem[30];
    char setor;
    float salario;

    if (pilha_vazia(p) || p == NULL)
            printf("Pilha invalida ou vazia\n");
    else
    {
        pilha p2 = cria_pilha();
        printf("Pilha:\n");

        while(!pilha_vazia(p))
        {
            le_topo(&p, &matricula, elem, &setor, &salario);
            pop(&p, matricula);
            push(&p2, matricula, elem, setor, salario);
        }
        while(!pilha_vazia(p2))
        {
            pop(&p2,matricula);
            push(&p, matricula, elem, setor, salario);
            printf("matricula: %ld\n", matricula);
            printf("nome: %s\n", elem);
            printf("setor: %c\n", setor);
            printf("salario: %.2f\n", salario);
        }
    }
}
