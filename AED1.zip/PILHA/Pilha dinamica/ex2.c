#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "ex2.h"

#define max 30

struct _funcionarios{
    long int matricula;
    char nome[max], setor;
    float salario;
    struct _funcionarios *prox;
};

pilha cria_pilha()
{
    return NULL;
}

int pilha_vazia(pilha p)
{
    if (p == NULL)
        return 1;
    else
        return 0;
}

int push(pilha *p, long int matricula, char nome[30], char setor, float salario)
{
    if((setor != 'g')&& (setor != 'c')&& (setor != 'a')&& (setor != 'f')&& (setor != 'G')&&(setor != 'C')&& (setor != 'A')&&(setor != 'F'))
        return 0;

    pilha N = (pilha) malloc(sizeof(struct _funcionarios));

    if (N == NULL) {
        return 0;
    }

    N->matricula = matricula;
    N->setor = setor;
    N->salario = salario;

    strcpy(N->nome, nome);

    N->prox = *p;
    *p = N;

    return 1;
}

int pop(pilha *p, int matricula)
{
    if (pilha_vazia(*p) == 1)
        return 0;

    pilha aux = *p;
    matricula = aux->matricula;
    *p = aux->prox;

    free(aux);

    return 1;
}

int le_topo(pilha *p, long int *matricula, char nome[30], char *setor, float *salario)
{
    if (pilha_vazia(*p) == 1)
        return 0;

    *matricula = (*p)->matricula;
    *setor = (*p)->setor;
    *salario = (*p)->salario;

    strcpy(nome, (*p)->nome);

    return 1;
}

int tamanho_pilha(pilha p){

    if(p == NULL)
        return -1;

    int cont = 0;
    pilha aux = p;

    while(aux->prox != NULL)
    {
        aux = aux->prox;
        cont++;
    }

    return cont;
}

int esvazia_pilha(pilha* p)
{

    if (*p == NULL)
        return 0;

    while (*p != NULL)
    {
        pilha aux = *p;
        *p = aux -> prox;
        free(aux);
    }

    return 1;
}

int apaga_pilha(pilha* p){

    return (esvazia_pilha(p));
}



