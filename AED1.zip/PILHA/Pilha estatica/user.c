#include <stdio.h>
#include <stdlib.h>
#include "ex1.h"

void imprime_topo(pilha p);
void imprime_pilha(pilha p);

int main(){

    pilha p;
    int ativo = 0;
    int i = 0;
    int n;
    char elem[20];

    while(ativo != 1){

        printf("--------------------------------------------\n");
        printf("--Pilha--\n");
        printf("\n 1 - Criar Pilha\n");
        printf(" 2 - Inserir elemento na Pilha\n");
        printf(" 3 - Remover elemento da Pilha\n");
        printf(" 4 - Imprimir Pilha\n");
        printf(" 5 - Imprimir topo da Pilha\n");
        printf(" 6 - Limpar Pilha\n");
        printf(" 7 - Apagar Pilha\n");
        printf(" 8 - Verificar tamanho da Pilha\n");
        printf(" 9 - Sair\n");
        printf("--------------------------------------------\n");

        scanf("%d", &n);
        setbuf(stdin, NULL);

        switch(n){

            case 1:
                p = cria_pilha();
                if(p == NULL)
                    printf("A pilha nao foi criada\n");
                else
                    printf("A pilha foi criada com sucesso\n");

                break;

            case 2:
                printf("Insira o elemento que deseja adicionar: ");
                scanf("%s", elem);

                if(push(p, elem) == 0)
                    printf("Nao foi possivel adicionar.\n");
                else
                    printf("O elemento %s foi incluido.\n", elem);

                break;

            case 3:
                scanf("%s", elem);

                if(pop(p, elem) == 0)
                    printf("O elemento %s nao foi encontrado.\n", elem);
                else
                    printf("O elemento %s foi removido.\n", elem);

                break;

            case 4:
                if(p != NULL)
                    imprime_Pilha(p);
                else
                    printf("Nao foi possivel imprimir.\n");

                break;

            case 5:
                if(p != NULL)
                    imprime_topo(p);
                else
                    printf("Nao foi possivel imprimir\n");

                break;

            case 6:
                if(esvazia_pilha(p) == 0)
                    printf("Nao existe nenhuma pilha.\n");
                else
                    printf("Pilha esvaziada.\n");

                break;

            case 7:
                apaga_pilha(&p);
                printf("Pilha apagada.\n");

                break;

            case 8:
                if (tamanho_pilha(p) >= 0)
                    printf("A Pilha tem tamanho igual a %d\n", tamanho_pilha(p));
                else
                    printf("Pilha invalida\n");

                break;

            case 9:
                ativo = 1;
                break;

            default:
                printf("opcao invalida!\n");
            }

    }

    return 0;
}

void imprime_Pilha(pilha p){

    if(pilha_vazia(p) == 1){

        printf("\n --Pilha Vazia--\n");
        return;
    }

    printf("\nPilha:\n");
    int i=0;
    char N[20];
    char aux[10][20];

    while(pilha_vazia(p)==0)
    {
        pop(p, N);
        strcpy(aux[i], N);
        i++;
    }

    for(int j=i-1; j>=0;j--)
    {
        printf("%s\n", aux[j]);
        push(p, aux[j]);
    }
}

void imprime_topo(pilha p){

    if(pilha_vazia(p) == 1){

        printf("\n --Pilha Vazia--\n");
        return;
    }
    char x[20];
    get_topo(p, x);
    printf("%s\n", x);
}
