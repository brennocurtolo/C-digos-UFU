#ifndef PROVA_H_INCLUDED
#define PROVA_H_INCLUDED

typedef struct _pilha * pilha;

pilha cria_pilha ();

int pilha_vazia (pilha p);

int pilha_cheia (pilha p);

int push (pilha p, char *elem);

int pop (pilha p, char *elem);

int get_topo (pilha p, char *elem);

int esvazia_pilha(pilha p);

int apaga_pilha (pilha p);

int tamanho_pilha(pilha p);

#endif // PROVA_H_INCLUDED
