#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ex1.h"

#define max 10
#define max2 20

struct _pilha{
  char string[max][max2];
  int topo;
};

pilha cria_pilha ()
{
    pilha p = (pilha)malloc(sizeof(struct _pilha));
    if (p != NULL)
        p->topo = -1;

    return p;
}

int pilha_vazia (pilha p)
{
    if (p -> topo == -1)
        return 1;
    else
        return 0;
}

int pilha_cheia (pilha p)
{
    if (p -> topo == max - 1)
        return 1;
    else
        return 0;
}


int push (pilha p, char *elem)
{
    if (p == NULL || pilha_cheia(p) == 1)
        return 0;

    p -> topo++;
    strcpy (p -> string[p -> topo], elem);
    return 1;
}

int pop (pilha p, char *elem)
{
    if (p == NULL || pilha_vazia(p) == 1)
        return 0;

     strcpy (elem, p -> string[p -> topo]);
     p -> topo--;
     return 1;

}

int get_topo (pilha p, char *elem)
{
    if (p == NULL || pilha_vazia(p) == 1)
        return 0;

    strcpy (elem, p -> string[p -> topo]);
    return 1;
}

int esvazia_pilha(pilha p)
{
    if(p == NULL || pilha_vazia(p))
        return 0;

    p->topo = -1;
    return 1;
}

int apaga_pilha (pilha p)
{
    if(p == NULL)
        return 0;

    free(p);
    p = NULL;
    return 1;

}

int tamanho_pilha(pilha p)
{
    if(p == NULL || pilha_vazia(p))
        return 0;

    return p -> topo + 1;
}






