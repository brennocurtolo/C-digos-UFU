#ifndef PILHA_H_INCLUDED
#define PILHA_H_INCLUDED

typedef struct no* Pilha;

union info
{
    char caracter;
    float number;

};

typedef union info Info;

Pilha cria_pilha();

int pilha_vazia(Pilha);

int push(Pilha, Info);

//int le_topo(Pilha *p, long int *matricula, char nome[30], char *setor, float *salario);

int pop(Pilha *, Info);

int tamanho_Pilha(Pilha);

int apaga_Pilha(Pilha *);

int esvazia_Pilha(Pilha *);

#endif // LISTA_H_INCLUDED
