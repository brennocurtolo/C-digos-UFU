#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "EX2.h"

/*void imprime_topo(Pilha p);
void imprime_Pilha(Pilha p);
*/

int main(){

    Info a;
    int h;
    Pilha p;
    int ativo = 0;
    int i = 0;
    int n;

    while(ativo != 1){

        printf("--------------------------------------------\n");
        printf("--Pilha--\n");
        printf("\n[1] Criar Pilha\n");
        printf("[2] Inserir elemento na Pilha\n");
        printf("[3] Remover elemento da Pilha\n");
        printf("[4] Imprimir Pilha\n");
        printf("[5] Imprimir topo da Pilha\n");
        printf("[6] Limpar Pilha\n");
        printf("[7] Apagar Pilha\n");
        printf("[8] Verificar tamanho da Pilha\n");
        printf("[9] Sair\n");
        printf("--------------------------------------------\n");
        printf("Digite o valor desejado: ");

        scanf("%d", &n);
        setbuf(stdin, NULL);

        switch(n){

            case 1:
                p = cria_pilha();
                printf("Pilha criada\n");

                break;

            case 2:

                printf("digite 0 para escrever um numero real, ou 1 para escrever um caracter\n");
                scanf("%d", &h);

                if(h == 0){
                    scanf("%f", &a.a);
                    push(p, a, h);
                }

                else if(h == 1){
                    scanf("%c", &a.b);
                    push(p, a, h);
                }
                else
                    printf("numero invalido\n");

                break;

            case 3:


                break;

            case 4:
                /*if(p != NULL)
                    imprime_Pilha(p);

                else
                    printf("Nao foi possivel imprimir.\n");
            */
                break;

            case 5:


                break;

            case 6:
                if(esvazia_Pilha(&p) == 0)
                    printf("Nao existe nenhuma pilha.\n");
                else
                    printf("Pilha esvaziada.\n");

                break;

            case 7:
                apaga_Pilha(&p);
                printf("Pilha apagada.\n");

                break;

            case 8:
                if (tamanho_Pilha(p) >= 0)
                    printf("A Pilha tem tamanho igual a %d\n", tamanho_Pilha(p));
                else
                    printf("Pilha invalida\n");

                break;

            case 9:
                ativo = 1;
                break;

            default:
                printf("opcao invalida!\n");
            }

    }

    return 0;
}

/*void imprime_Pilha(Pilha p)
{
    long int matriculas;
    char elem[30];
    char setors;
    float salarios;

    if (pilha_vazia(p) || p == NULL)
            printf("Pilha invalida ou vazia\n");
    else
    {
        Pilha p2 = cria_pilha();
        printf("A pilha possui os elementos:\n");

        while(!pilha_vazia(p))
        {
            le_topo(&p, &matriculas, elem, &setors, &salarios);
            push(&p2, matriculas, elem, setors, salarios);
            pop(&p, matriculas);
        }
        while(!pilha_vazia(p2))
        {
            if(p2 != NULL)
            {
                le_topo(&p2, &matriculas, elem, &setors, &salarios);
                printf("matricula: %ld\n", matriculas);
                printf("nome: %s\n", elem);
                printf("setor: %c\n", setors);
                printf("salario: R$%.2f\n", salarios);
            }
            push(&p, matriculas, elem, setors, salarios);
            pop(&p2, matriculas);
        }
    }
}*/
