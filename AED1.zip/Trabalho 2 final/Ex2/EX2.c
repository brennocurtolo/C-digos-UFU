#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "EX2.h"
#define MAX 30

struct no{
    Info elem;
    struct no* prox;
};

Pilha cria_pilha()
{
    return NULL;
}

int pilha_vazia(Pilha p)
{
    if (p == NULL)
        return 1;
    else
        return 0;
}

int push(Pilha p, Info elem)
{

    Pilha N = (Pilha) malloc(sizeof(struct no));

    if (N == NULL) {
        return 0;
    }

    p->info.f_number = elem.a;

    else{
        p->info.c_caracter = elem.b;
    }

    N->prox = p;
    p = N;

    return 1;
}

int pop(Pilha *p, Uniao elem)
{
    if (pilha_vazia(*p) == 1)
        return 0;

    Pilha aux = *p;
    if(p->tipo == 0){
        p->info.f_number =
    }
    else
        p->info.c_caracter =
    *p = aux->prox;

    free(aux);

    return 1;
}

/*int le_topo(Pilha *p, union elem)
{
    if (pilha_vazia(*p) == 1)
        return 0;

    *matricula = (*p)->matricula;
    *setor = (*p)->setor;
    *salario = (*p)->salario;

    strcpy(nome, (*p)->nome);

    return 1;
}
*/
int tamanho_Pilha(Pilha p){

    if(p == NULL)
        return -1;

    int cont = 0;
    Pilha aux = p;

    while(aux->prox != NULL)
    {
        aux = aux->prox;
        cont++;
    }

    return cont+1;
}

int esvazia_Pilha(Pilha* p)
{

    if (*p == NULL)
        return 0;

    while (*p != NULL)
    {
        Pilha aux = *p;
        *p = aux -> prox;
        free(aux);
    }

    return 1;
}

int apaga_Pilha(Pilha* p){

    return (esvazia_Pilha(p));
}



