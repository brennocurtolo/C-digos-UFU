#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

int main()
{
    int i, v, troca = 0, copia, vetor [30], s = 30;
    char q[s];

    printf ("Digite a quantidade de valores que deseja inserir:\n");
    scanf ("%s", q);

    for (i = 0; (i < s) && (q[i] != '\0'); i++){
        if ((isdigit (q[i])) == 0){                           //se nao for um numero (0 - falso)
            printf ("Nao eh um numero!\n");
            return 1;
        }
    }
    v = atof (q);
    if (v > s){
        printf ("Erro. Maximo de valores excedido (30)\n");
        return main ();
    }

    printf ("Digite os valores para obte-los em ordem crescente:\n");

    for (i = 0; i < v; i++){
        printf ("valor:\n");
        scanf ("%d", &vetor[i]);

    }

    printf ("\n");

    do{                                                   //bubble sort mais eficiente
        troca = 0;
        for (i = 0; i < v - 1; i++){
            if (vetor [i] > vetor [i + 1]){
                copia = vetor [i];
                vetor [i] = vetor [i + 1];
                vetor [i + 1] = copia;
                troca = 1;                                //identifica que o teste � verdadeiro, houve ao menos 1 troca
            }
        }
    }while (troca);                                        //while (troca) == while (troca == 1) (qualquer coisa diferente de 0 � verdadeiro)

    printf ("\n");

    printf ("A ordem eh:\n");
    for (i = 0; i < v; i++){
        printf ("%d ", vetor[i]);
    }
    printf ("\n");

    return 0;
}

 /*for (j = 0; j < 4; j++){                            //algoritmo bolha (bubble sort) //menos eficiente
        for (i = 0; i < 4; i++){
            if (vetor [i] > vetor [i + 1]){
                copia = vetor [i];
                vetor [i] = vetor [i + 1];
                vetor [i + 1] = copia;
            }
        }
    }*/
