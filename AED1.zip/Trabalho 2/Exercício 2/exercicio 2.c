/*
    Exercicio 2

    - Calculo de Arranjo simples de N elementos tomados P a P;

    por Brenno Cavalcanti 2021.
*/
#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, p;                            //variaveis de N elementos e P grupos
    int r;
    int v = 1;                           //fatorial
    int i = 1;                           //fatorial

    printf ("Digite um valor 'N' para obter o arranjo simples num valor de 'P' grupos:\n");

    printf ("N: ");
    scanf ("%d", &n);
    printf ("P: ");
    scanf ("%d", &p);

    r = n - p;
    for (i; r > 0; r--){
        i = i * r;
    }

    for (v; n > 0; n--){
        v = v * n;
    }

    r = v / i;

    printf("%d\n", r);
    return 0;
}
