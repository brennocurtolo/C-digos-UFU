#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    int i, matricula;
    float nota;
    char a, b, nome[30];

    FILE *dados = NULL;


    dados = fopen (argv[1], "a");


}
/*
    while ((nome, 30, b) != NULL) {
        printf ("%s", nome);
    }
*/

/*
    getchar (); //pausa no programa
    exit (1);
*/
/*
    char nome[30];
    fputs (nome, b); //serve para varios caracteres

    char caracter;
    fputc (caracter, b); //serve para um unico caracter

    fgetc e fgets //mesma ideia mas para alocar no documento ou apresentar na tela
    EXEMPLO

    char x[100];
    fgets (x, 100, stdin);  //STDIN pega o que for digitado no TECLADO
    printf ("%s", x);
*/
/*
    EXEMPLO PARA COPIAR DADOS DE UM ARQUIVO PARA OUTRO

    PRIMEIRA OP�AO COM WHILE:
    void copiarconteudo (FILE *file1, FILE *file2){
            char leitor [1000];
            while (fgetc ((leitor, 1000, file1) != NULL){           //ou pode usar EOF ao inves de NULL (serve para rodar e nao parar na quebra de linha)
                fputs (leitor, file2);
            }

    }

    SEGUNDA OP�AO COM FOR

    char a;
    for (i = 0; (a = fgetc (file1)) != EOF; i++){
        fputc (a, file2);
    }
*/
