#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char sim (char s);
char nao (char n);

struct cadastro{
    char nome[30];
    char cargo[20];
    int idade;
    int matricula;
    float salario;
};

int main()
{
    struct cadastro funcionarios[10];

    int i;
    char r, s, n;

    /*for (i = 0; i < 10; i++){

        funcionarios[i].matricula = 0;

        strcpy (funcionarios[i].nome, "NULL");


        funcionarios[i].idade = 0;


        strcpy (funcionarios[i].cargo, "NULL");


        funcionarios[i].salario = 0.0;

    }*/

    printf ("Ja possui cadastro? (s/n)\n");
    scanf ("%s", &r);
    if (r == 's' && r != '\0'){
        sim (s);
    }
    else if (r == 'n' && r != '\0'){
        nao (n);
    }
    else{
        fprintf (stderr, "Digite uma opcao valida.\n");
        return main ();
    }

    return 0;
}

char nao (char n){
    char s;
    struct cadastro funcionarios[10];

    int i;

    for (i = 0; i < 10; i++){

        printf ("Digite sua matricula:\n");
        scanf ("%d%*c", &funcionarios[i].matricula);

        if (funcionarios[i].matricula == 0){
            printf ("fim\n");
            return 1;
        }

        printf ("Digite seu nome:\n");
        scanf ("%s%*c", funcionarios[i].nome);

        printf ("Digite sua idade:\n");
        scanf ("%d%*c", &funcionarios[i].idade);

        printf ("Digite seu cargo:\n");
        scanf ("%s%*c", funcionarios[i].cargo);

        printf ("Digite seu salario:\n");
        scanf ("%f%*c", &funcionarios[i].salario);

        printf ("Cadastro realizado!\n");

        break;
    }

    return sim (s);
}

char sim (char s){

    struct cadastro funcionarios[10];

    int i, posicao;
    char nome[30];

    printf ("Digite seu nome:\n");
    scanf ("%s%*c", nome);

    for (i = 0; i < 10; i++){

        if (strcmp (nome, funcionarios[i].nome) == 0){
            printf("\nRegistro encontrado!\n");
            posicao = i;
        }
        else{
            posicao = -1;
        }
    }
        if (posicao = -1){
            printf("\nRegistro nao encontrado!\n");
            return main ();
        }
        else{
            printf ("Registro encontrado:\n");
            printf ("matricula: %d", funcionarios[i].matricula);
            printf ("nome: %s", funcionarios[i].nome);
            printf ("idade: %d", funcionarios[i].idade);
            printf ("cargo: %s", funcionarios[i].cargo);
            printf ("salario: %f", funcionarios[i].salario);
        }

    return main();
}

//gets(funcionarios[i].nome);
