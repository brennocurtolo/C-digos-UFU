#ifndef FONTE_H_INCLUDED
#define FONTE_H_INCLUDED

typedef struct _lista* lista;   //criado um apelido para um ponteiro do tipo lista
lista cria_lista ();
int lista_vazia (lista li);
int lista_cheia (lista li);
int insere_elem (lista li, char elem[]);
int remove_elem (lista li, char elem[]);
int get_elem(lista li, char elem[], int x);
int esvazia_lista (lista li);
int apaga_lista (lista* li);

#endif // FONTE_H_INCLUDED
