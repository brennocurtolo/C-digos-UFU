#include <stdio.h>
#include <stdlib.h>

#include "fonte.h"

void imprime(lista li);
int main()
{
    int maximo = 0, n = 0;
    lista li;
    int x;
    char elem[11];

    while(maximo != 7){

        printf("\n");
        printf(" 1 - Criar uma lista\n");
        printf(" 2 - Inserir uma string na lista\n");
        printf(" 3 - Remover uma string da lista\n");
        printf(" 4 - Imprimir Lista\n");
        printf(" 5 - Limpar Lista\n");
        printf(" 6 - Apagar Lista\n");
        printf(" 7 - Sair\n");
        printf("\n");

        scanf("%d", &n);
        setbuf(stdin, NULL);

        switch(n){
            case 1:
                if(li != NULL){
                    printf("a lista ja foi criada\n");
                    break;
                }
                li = cria_lista();
                if(li == NULL)
                    printf("A lista nao foi criada!\n");
                else
                    printf("A lista foi criada!\n");
                break;
            case 2:
                printf ("Digite a string:\n");
                scanf("%s", elem);
                insere_elem(li, elem);
                break;
            case 3:
                printf ("Qual elemento deseja remover?\n");
                scanf("%s", elem);
                remove_elem (li, elem);
                break;
            case 4:
                imprime(li);
                break;
            case 5:
                esvazia_lista(li);
                if(li == NULL)
                    printf("erro ao esvaziar a lista\n");
                else
                    printf("lista esvaziada");
                break;
            case 6:
                apaga_lista(&li);
                if(li == 0)
                    printf("memoria liberada\n");
                break;
            case 7:
                maximo = 7;
                break;
            default:
                printf("opcao invalida!\n");
        }
    }
    return 0;
}
void imprime(lista li){

    if(lista_vazia(li) == 1){

        printf("\n --Lista Vazia--\n");

    }
    printf("\nLista: ");
    int i;
    char y[20];

    for(i = 1; get_elem(li, y, i) == 1; i++){
        printf(" %s ", y);
    }
    printf("\nA lista tem %d elementos.\n", i - 1);
}
