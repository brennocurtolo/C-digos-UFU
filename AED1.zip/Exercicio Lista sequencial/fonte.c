/*
    Lista Sequencial n�o ordenada
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fonte.h"

#define max 20
#define max2 11

struct _lista{
    char string[max][max2];
    int fim;                                    //quantidade final que vai ter de strings, sendo que o maximo � 20 com 11 caracteres.
};

typedef struct _lista lista2;

lista cria_lista (){
    lista li = (lista) malloc(sizeof(lista2));   //ao inves de usar o (struct _lista) usei o (lista2) - apelido.
    if (li != NULL)
        li -> fim = 0;                           //o li (ponteiro pra struct) vai apontar para a struct e para um dado dentro dela o (fim).

    return li;
}

int lista_vazia (lista li){
    if (li -> fim == 0)
        return 1;                               //vazia
    else
        return 0;                               //n�o vazia
}

int lista_cheia (lista li){
    if (li -> fim == max)
        return 1;                               //cheia
    else
        return 0;                               //n�o cheia
}

//sem ordena��o (CHAR), ou para (INT ou FLOAT) sem o strcpy
int insere_elem (lista li, char elem[]){

    if (li == NULL || lista_cheia(li) == 1)     //se o endere�o � null ou a fun��o (lista_cheia) do endere�o esta cheia
        return 0;

    strcpy(li -> string[li -> fim], elem);     //strcpy (primeiro o destino da copia, qual item copiar) isso � para char
    li -> fim++;

    return 1;
}

//ordenada para INTEIROS (sem o strcpy), para CHAR esta faltando a ordem alfabetica
/*
int insere_elem (lista li, char elem[]){

    if (li == NULL || lista_cheia(li) == 1)
        return 0;                               //falha

    if (lista_vazia(li) == 1 || elem >= li -> string[li -> fim - 1]){
        strcpy(li -> string[li -> fim], elem);
    }

    else{
        int i, aux = 0;                             //vari�vel auxiliar(aux)

        while (elem >= li -> string[aux])
            aux++;

        for (i = li -> fim; i > aux; i--){
            li -> string[i] = li -> string[i - 1];
        }

        strcpy(li -> string[aux], elem);        //PARA INTEIROS usa-se        li -> string[aux] = elem;

    }

    li -> fim++;

    return 1;
}
*/

//sem ordena��o (CHAR), ou para (INT ou FLOAT) sem o strcpy
int remove_elem (lista li, char elem[]){
    if (li == NULL || lista_vazia (li) == 1)
        return 0;

    int i, aux = 0;

    while (aux < li -> fim && strcmp (li -> string[aux], elem)!= 0)             //= 0 se ambos forem iguais, < 0 elem maior que a primeira e > 0 elem menor que a primeira
        aux++;

    if (aux == li -> fim)
        return 0;

    for (i = aux + 1; i < li -> fim; i++){
       strcpy(li -> string[i - 1], li -> string[i]);
    }

    li -> fim--;

    return 1;

}

//ordenada para INTEIROS (sem o strcpy), para CHAR esta faltando a ordem alfabetica (usar strcmp)
/*
int remove_elem (lista li, char elem){
    if (li == NULL || lista_vazia (li) == 1 || elem < li -> string[0] || elem > li -> string[li -> fim - 1])
        return 0;

    int i, aux = 0;

    while (aux < li -> fim && li -> string[aux] < elem)
        aux++;

    if (aux == li -> fim || li -> string[aux] > elem)
        return 0;

    for (i = aux + 1; i < li -> fim; i++){
       strcpy(li -> string[i - 1], li -> string[i]);
    }

    li -> fim--;

    return 1;

}
*/
int get_elem(lista li, char elem[], int x){
    if (li == NULL || lista_vazia (li) == 1 || x < 1 || x > li -> fim)
        return 0;

    strcpy (elem, li -> string[x - 1]);
        return 1;
}

int esvazia_lista (lista li){
    if (li == NULL)
        return 0;

    li -> fim = 0;
    return 1;
}

int apaga_lista (lista* li){
    if (*li == NULL)
        return 0;

    free(*li);
    *li = NULL;

    return 1;
}



