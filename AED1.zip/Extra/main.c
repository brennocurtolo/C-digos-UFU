#include <stdio.h>
#include "lista.h"

void imprime_lista(Lista lst);

int main(){

    Lista lst;
    int ativo = 0;
    int i = 0;
    int n;
    char elem;

    while(ativo != 7){

        printf("--------------------------------------------\n");
        printf("--LISTA %d--\n", i + 1);
        printf("\n[1] Criar lista\n");
        printf("[2] Inserir elemento na lista\n");
        printf("[3] Remover elemento da lista\n");
        printf("[4] Imprimir Lista\n");
        printf("[5] Remover ultima vogal da lista\n");
        printf("[6] Apagar Lista\n");
        printf("[7] Sair\n");
        printf("--------------------------------------------\n");
        printf("Digite o valor desejado: ");

        scanf("%d", &n);
        setbuf(stdin, NULL);

        switch(n){

            case 1:
                lst = cria_lista();
                if (lst == NULL)
                    printf("Lista nao criada\n");
                else
                    printf("Lista criada com sucesso\n");
                break;

            case 2:
                printf("Insira o elemento: ");

                scanf("%c", &elem);

                if(insere_elem(&lst, elem) == 0)
                    printf("Nao foi possivel adicionar.\n");

                else
                    printf("O elemento %c foi incluido.\n", elem);

                break;

            case 3:
                printf("Digite o elemento que deseja remover: ");

                scanf("%c", &elem);

                if(remove_elem(&lst, elem) == 0)
                    printf("O elemento %c nao foi encontrado.\n", elem);

                else
                    printf("O elemento %c foi removido.\n", elem);

                break;

            case 4:
                if(lst != NULL)
                    imprime_lista(lst);

                else
                    printf("Nao foi possivel imprimir.\n");

                break;

            case 5:
                if(remove_ultimavogal(&lst, &elem) == 0)
                    printf("Nao foi encontrada nenhuma vogal\n");

                else
                    printf("A vogal %c foi removida.\n", elem);

                break;

            case 6:
                apaga_lista(&lst);
                printf("Lista apagada.\n");
                break;

            case 7:
                ativo = 7;
                break;

            default:
                printf("opcao invalida!\n");
            }

    }

    return 0;
}

void imprime_lista(Lista lst){

    if(lista_vazia(lst) == 1){

        printf("\n --A lista esta vazia--\n");
        return;
    }

    printf("\nLista: ");
    int i;
    char N;

    for(i = 1; get_elem_pos(lst, i, &N) == 1; i++){

        printf(" %c ", N);
    }
    printf("\n");
    printf("existem %d elementos na lista.\n", i - 1);
}
