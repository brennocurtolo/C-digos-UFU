#include <stdlib.h>
#include "lista.h"

struct no{

    char info;
    Lista prox;
};

Lista cria_lista(){


    Lista cab;
    cab = (Lista)malloc(sizeof(struct no));

    if(cab != NULL){
        cab -> prox = NULL;
    }

    return cab;
}

int lista_vazia(Lista lst){

    if(lst -> prox == NULL)
        return 1;

    else
        return 0;
}

int insere_elem(Lista *lst, char elem){


    Lista N = (Lista) malloc(sizeof(struct no));
    if(N == NULL)
        return 0;
    N->info = elem;
    N->prox = (*lst)->prox;
    (*lst)->prox = N;

    return 1;
}

int remove_elem(Lista *lst, char elem)
{

    if(lista_vazia(*lst) == 1)
        return 0;

    Lista aux = *lst; //Ponteiro auxiliar para o 1� n�

    while(aux -> prox != NULL && aux -> prox -> info != elem)
        aux = aux -> prox;

    if(aux -> prox == NULL)
        return 0; //Falha

    Lista aux2 = aux -> prox;   //Aponta n� a ser removido
    aux -> prox = aux2 -> prox; //Retira n� da lista
    free(aux2);                 //Libera mem�ria alocada

    return 1;
}

int remove_ultimavogal(Lista *lst, char *elem)
{
    if(lista_vazia(*lst) == 1)
        return 0; //Falha

    int verifica = 0;
    Lista aux = *lst; //Ponteiro auxiliar para o 1� n�
    Lista aux2 = NULL;

    while(aux -> prox != NULL)
    {
        if (aux->prox->info == 'A' || aux->prox->info == 'E' || aux->prox->info == 'I' || aux->prox->info == 'O' || aux->prox->info == 'U'
            || aux->prox->info == 'a' || aux->prox->info == 'e' || aux->prox->info == 'i' || aux->prox->info == 'o' || aux->prox->info == 'u')
        {
            verifica = 1;
            aux2 = aux;
        }
        aux = aux->prox;
    }
    if (verifica == 0)
        return 0; // Falha

    *elem = aux2->prox->info;

    aux = aux2->prox;
    aux2->prox = aux->prox;

    free(aux);
    return 1;
}

int get_elem_pos(Lista lst, int pos, char *elem){

    if(lista_vazia(lst) || pos <= 0)
        return 0; //Falha

    int cont = 1;
    Lista Aux = lst -> prox;

    while(Aux -> prox != NULL && cont < pos){

        Aux = Aux -> prox;
        cont++;
    }

    if(cont < pos)  //Nao existe a posi��o solicitada na lista
        return 0;    //Falha

    *elem = Aux -> info;  //Retorna o valor do elemento da posi��o desejada
    return 1;             //sucesso
}


int apaga_lista(Lista *lst){

    if(lst  == NULL)
        return 0;

    while(*lst != NULL){

        Lista Aux = *lst;
        *lst = Aux -> prox;
        free(Aux);
    }

    return 1;
}
