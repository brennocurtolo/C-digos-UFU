#ifndef LISTA_H_INCLUDED
#define LISTA_H_INCLUDED

typedef struct no * Lista;

Lista cria_lista();

int lista_vazia(Lista lst);

int insere_elem(Lista *lst, char elem);

int remove_elem(Lista *lst, char elem);

int remove_elem(Lista *lst, char elem);

int remove_ultimavogal(Lista *lst, char *elem);

int get_elem_pos(Lista lst, int pos, char *elem);

int apaga_lista(Lista *lst);

#endif // LISTA_H_INCLUDED
