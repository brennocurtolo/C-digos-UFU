#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sequencial.h"

#define max 20
#define qtd 11

struct _lista{
    char string[max][qtd];
    int fim;

};

lista cria_lista (){

    lista la = (lista) malloc(sizeof(struct _lista));
    if (la != NULL)
        la -> fim = 0;
    return la;
}

int lista_vazia(lista la){
    if (la -> fim == 0)
        return 1;
    else
        return 0;
}

int lista_cheia(lista la)
{
    if (la->fim == max)
        return 1;                                 // Lista cheia
    else
        return 0;                                 // Lista NÃO cheia
}
int insere_elem(lista la, char elemento[])
{
    if (la == NULL || lista_cheia(la) == 1)
        return 0;
    strcpy(la->string[la -> fim], elemento);                     // Insere elemento
    la->fim++;                                    // Avança o Fim
    return 1;
}
int remove_elem (lista la, char elemento[])
{
    if (la == NULL || lista_vazia(la) == 1)
        return 0; // Falha
    int i, Aa = 0;
    // Percorrimento até achar o elem ou final de lista
    while (Aa < la->fim && strcmp(la -> string[Aa], elemento) != 0)
    {
        Aa++;                                  // Final de lista (∄ elem)
    }
    if (Aa == la->fim)                         // Falha
        return 0;

    // Deslocamento à esq. do sucessor até o final da lista
    for (i = Aa + 1; i < la->fim; i++)
        strcpy(la->string[i - 1], la->string[i]);
    la -> fim--;                                 // Decremento do campo Fim
    return 1;                                    // Sucesso
}
int get_elem(lista la, char elemento[], int x)
{
    if(la == NULL || x > la -> fim || x < 1 || lista_vazia(la) == 1)
        return 0;
    strcpy(elemento, la -> string[x - 1]);
    return 1;
}
int esvazia_lista(lista la)
{
    if(la == NULL)
        return 0;
    la -> fim = 0;
    return 1;
}
int apaga_lista(lista *la){
    if(*la == NULL)
        return 0;
    free(*la);
    *la = NULL;
    return 1;
}
