#include <stdio.h>
#include "sequencial.h"

void imprime(lista li);
int main()
{
    int ativo = 0, n = 0;
    lista la;
    int x;
    char elemento[11];

    while(ativo != 7){

        printf("\n");
        printf(" 1 - Alocar uma lista\n");
        printf(" 2 - Inserir uma string na lista\n");
        printf(" 3 - Remover uma string da lista\n");
        printf(" 4 - Imprimir Lista\n");
        printf(" 5 - Limpar Lista\n");
        printf(" 6 - Apagar Lista\n");
        printf(" 7 - Sair\n");
        printf("\n");

        scanf("%d", &n);
        setbuf(stdin, NULL);

        switch(n){
            case 1:
                if(la != NULL){
                    printf("a lista ja foi criada\n");
                    break;
                }
                la = cria_lista();
                if(la == NULL)
                    printf("A lista nao foi criada\n");
                else
                    printf("A lista foi criada\n");
                break;
            case 2:
                scanf("%s", elemento);
                insere_elem(la, elemento);
                break;
            case 3:
                scanf("%s", elemento);
                remove_elem (la, elemento);
                break;
            case 4:
                imprime(la);
                break;
            case 5:
                esvazia_lista(la);
                if(la == NULL)
                    printf("erro ao esvaziar a lista\n");
                else
                    printf("lista esvaziada");
                break;
            case 6:
                apaga_lista(&la);
                if(la == 0)
                    printf("memoria liberada\n");
                break;
            case 7:
                ativo = 7;
                break;
            default:
                printf("opcao invalida!\n");
        }
    }
    return 0;
}
void imprime(lista la){

    if(lista_vazia(la) == 1){

        printf("\n --Lista Vazia--\n");

    }
    printf("\nLista: ");
    int i;
    char n[20];

    for(i = 1; get_elem(la, n, i) == 1; i++){
        printf(" %s ", n);
    }
    printf("\nA lista tem %d elementos.\n", i - 1);
}
