#ifndef SEQUENCIAL_H_INCLUDED
#define SEQUENCIAL_H_INCLUDED

typedef struct _lista *lista;
lista cria_lista();
void libera_lista(lista l);
int lista_vazia(lista la);
int lista_cheia(lista la);
int insere_elem(lista la, char elemento[]);
int remove_elem(lista la, char elemento[]);
int apaga_lista(lista *la);
int esvazia_lista(lista la);
int get_elem(lista la, char elemento[], int x);

#endif // SEQUENCIAL_H_INCLUDED
