#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "head3.h"

#define max 10

struct no{

  fila2 produto;
  struct no *prox;
};


struct Fila{

  struct no *ini;
  struct no *fim;
};

fila cria_fila ()
{
    fila p = (fila)malloc(sizeof(struct Fila));
    if (p != NULL){
        p -> ini = NULL;
        p -> fim = NULL;
    }

    return p;
}

int fila_vazia (fila p)
{
    if (p -> ini == NULL)
        return 1;
    else
        return 0;
}

int insere_fim (fila p, fila2 elem)
{
    struct no *N;
    N = (struct no *)malloc(sizeof(struct no));

    if (N == NULL)
        return 0;

    N -> produto = elem;
    N -> prox = NULL;

    if (fila_vazia(p) == 1)
        p -> ini = N;
    else
        (p -> fim) -> prox = N;

    p -> fim = N;

    return 1;
}

int remove_ini (fila p, fila2 *elem)
{
    if (fila_vazia(p) == 1)
        return 0;

    struct no *aux = p -> ini;
    *elem = aux -> produto;

    if (p -> ini ==  p -> fim)
        p -> fim = NULL;

    p -> ini = aux -> prox;
    free (aux);

     return 1;
}

int tamanho_fila (fila p){

    if(p == NULL)
        return -1;

    int contador = 0;
    struct no *aux = p -> ini;

    while(aux != NULL){
        contador++;
        aux = aux -> prox;
    }

    return contador;
}

int esvazia_fila (fila p)
{

    if (p == NULL)
        return -1;

    p -> fim = NULL;
    p -> ini = NULL;

    return 1;

}

int apaga_fila (fila *p)
{

    if (*p == NULL)
        return 0;

    free (*p);
    *p = NULL;

    return 1;
}













