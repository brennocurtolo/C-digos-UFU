#ifndef HEAD3_H_INCLUDED
#define HEAD3_H_INCLUDED
#define max 10

typedef struct Fila *fila;

struct _fila{
  int codigo;
  char descricao[max];
  float preco;
};

typedef struct _fila fila2;

fila cria_fila ();

int fila_vazia (fila p);

int insere_fim (fila p, fila2 elem);

int remove_ini (fila p, fila2 *elem);

int tamanho_fila (fila p);

int esvazia_fila (fila p);

int apaga_fila (fila *p);

#endif // HEAD3_H_INCLUDED
