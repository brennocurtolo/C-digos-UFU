#include <stdio.h>
#include <stdlib.h>
#include "head3.h"

void imprime_fila(fila p, fila2 elem);

int main(){

    fila p = NULL;
    fila2 elem;
    int ativo = 0;
    int n;

    while(ativo != 1){

        printf("--------------------------------------------\n");
        printf("--Fila--\n");
        printf("\n 1 - Criar Fila\n");
        printf(" 2 - Inserir cadastro na Fila\n");
        printf(" 3 - Remover cadastro da Fila\n");
        printf(" 4 - Imprimir Fila\n");
        printf(" 5 - Limpar Fila\n");
        printf(" 6 - Apagar Fila\n");
        printf(" 7 - Verificar tamanho da Fila\n");
        printf(" 8 - Sair\n");
        printf("--------------------------------------------\n");

        scanf("%d", &n);
        setbuf(stdin, NULL);

        switch(n){

            case 1:
                p = cria_fila();
                if(p == NULL)
                    printf("A fila nao foi criada\n");
                else
                    printf("A fila foi criada com sucesso\n");

                break;

            case 2:
                printf("Insira o codigo: ");
                scanf("%d", &elem.codigo);

                printf("Insira a descricao: ");
                scanf("%s", elem.descricao);

                printf("Insira o preco: ");
                scanf("%f", &elem.preco);

                printf ("\n");

                if(insere_fim(p, elem) == 0)
                    printf("Nao foi possivel adicionar.\n");
                else
                    printf("Codigo %d incluido.\n", elem.codigo);

                break;

            case 3:

                if(remove_ini(p, &elem) == 0)
                    printf("Lista vazia.\n");
                else
                    printf("O codigo %d foi removido.\n", elem.codigo);

                break;

            case 4:
                if(p != NULL)
                    imprime_fila(p, elem);
                else
                    printf("Nao foi possivel imprimir.\n");

                break;

            case 5:
                if(esvazia_fila(p) == 0)
                    printf("Nao existe nenhuma fila.\n");
                else
                    printf("Fila esvaziada.\n");

                break;

            case 6:
                apaga_fila(&p);
                printf("Fila apagada.\n");

                break;

            case 7:
                if (tamanho_fila(p) >= 0)
                    printf("O tamanho da Fila eh %d\n", tamanho_fila(p));
                else
                    printf("Fila invalida\n");

                break;

            case 8:
                ativo = 1;
                break;

            default:
                printf("opcao invalida!\n");
            }

    }

    return 0;
}

void imprime_fila(fila p, fila2 elem)
{
    if(fila_vazia(p) == 1){

        printf("\n --Fila Vazia--\n");
        return;
    }
    printf("\nFila:\n\n");

    fila aux = cria_fila();

    while (fila_vazia(p) == 0)
    {
        remove_ini (p, &elem);

        printf("Codigo: %d\n", elem.codigo);
        printf("Descricao: %s\n", elem.descricao);
        printf("Preco: %.2f\n", elem.preco);

        insere_fim(aux, elem);
        printf ("\n\n");
    }
     while(fila_vazia(aux)==0)
    {
        remove_ini(aux, &elem);
        insere_fim(p, elem);
    }

}
