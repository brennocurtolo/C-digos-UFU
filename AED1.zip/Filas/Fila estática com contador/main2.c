#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "head2.h"

#define max 30
#define max2 10

struct Fila{

  char cadastro[max2][max];
  int ini, cont;
};

fila cria_fila ()
{
    fila p = (fila)malloc(sizeof(struct Fila));
    if (p != NULL){
        p -> ini = 0;
        p -> cont = 0;  //(fila) fazia
    }

    return p;
}

int fila_vazia (fila p)
{
    if (p -> cont == 0)
        return 1;
    else
        return 0;
}

int fila_cheia (fila p)
{
    if (p -> cont == max2)
        return 1;
    else
        return 0;
}

int insere_fim (fila p, char *elem)
{
    if (fila_cheia(p) == 1)
        return 0;

    //Insere elemento no final
    strcpy (p -> cadastro[(p -> ini + p -> cont)% max2], elem);

    p -> cont++;

    return 1;
}

int remove_ini (fila p, char *elem)
{
    if (p == NULL || fila_vazia(p) == 1)
        return 0;

     strcpy (elem, p -> cadastro[p -> ini]);
     p -> ini = (p -> ini + 1) % max2;
     p -> cont--;

     return 1;
}

int tamanho_fila (fila p){

    if(p == NULL)
        return -1;

    return p -> cont;
}

int esvazia_fila (fila p)
{

    if (p == NULL)
        return -1;

    p -> ini = 0;

    return 1;

}

int apaga_fila (fila *p)
{

    if (*p == NULL)
        return 0;

    free (*p);
    *p = NULL;

    return 1;
}














