#ifndef HEAD_H_INCLUDED
#define HEAD_H_INCLUDED
#define max 20

typedef struct Fila *fila;

fila cria_fila ();

int fila_vazia (fila p);

int fila_cheia (fila p);

int insere_fim (fila p, char *elem);

int remove_ini (fila p, char *elem);

int tamanho_fila (fila p);

int esvazia_fila (fila p);

int apaga_fila (fila *p);

#endif // HEAD_H_INCLUDED

