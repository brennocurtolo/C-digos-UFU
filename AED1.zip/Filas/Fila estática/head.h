#ifndef HEAD_H_INCLUDED
#define HEAD_H_INCLUDED
#define max 20

typedef struct Aluno *aluno;

struct _aluno{
  long int matricula;
  char nome[max];
  float nota;
  char situacao;
};

typedef struct _aluno alu;

aluno cria_fila ();

int fila_vazia (aluno p);

int fila_cheia (aluno p);

int insere_fim (aluno p, alu elem);

int remove_ini (aluno p, alu *elem);

int tamanho_fila (aluno p);

int esvazia_fila (aluno p);

int apaga_fila (aluno *p);

#endif // HEAD_H_INCLUDED
