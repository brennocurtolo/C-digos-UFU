#include <stdio.h>
#include <stdlib.h>
#include "head.h"

void imprime_fila(aluno p, alu elem);

int main(){

    aluno p = NULL;
    alu elem;
    int ativo = 0;
    int n;

    while(ativo != 1){

        printf("--------------------------------------------\n");
        printf("--Fila--\n");
        printf("\n 1 - Criar Fila\n");
        printf(" 2 - Inserir cadastro na Fila\n");
        printf(" 3 - Remover cadastro da Fila\n");
        printf(" 4 - Imprimir Fila\n");
        printf(" 5 - Limpar Fila\n");
        printf(" 6 - Apagar Fila\n");
        printf(" 7 - Verificar tamanho da Fila\n");
        printf(" 8 - Sair\n");
        printf("--------------------------------------------\n");

        scanf("%d", &n);
        setbuf(stdin, NULL);

        switch(n){

            case 1:
                p = cria_fila();
                if(p == NULL)
                    printf("A fila nao foi criada\n");
                else
                    printf("A fila foi criada com sucesso\n");

                break;

            case 2:
                printf("Insira a matricula: ");
                scanf("%ld", &elem.matricula);

                printf("Insira o nome: ");
                scanf("%s", elem.nome);

                printf("Insira a nota: ");
                scanf("%f", &elem.nota);

                printf ("\n");

                if(insere_fim(p, elem) == 0)
                    printf("Nao foi possivel adicionar.\n");
                else
                    printf("Aluno(a) %s incluido(a).\n", elem.nome);

                break;

            case 3:

                if(remove_ini(p, &elem) == 0)
                    printf("Lista vazia.\n");
                else
                    printf("O aluno %s foi removido.\n", elem.nome);

                break;

            case 4:
                if(p != NULL)
                    imprime_fila(p, elem);
                else
                    printf("Nao foi possivel imprimir.\n");

                break;

            case 5:
                if(esvazia_fila(p) == 0)
                    printf("Nao existe nenhuma fila.\n");
                else
                    printf("Fila esvaziada.\n");

                break;

            case 6:
                apaga_fila(&p);
                printf("Fila apagada.\n");

                break;

            case 7:
                if (tamanho_fila(p) >= 0)
                    printf("O tamanho da Fila eh %d\n", tamanho_fila(p));
                else
                    printf("Fila invalida\n");

                break;

            case 8:
                ativo = 1;
                break;

            default:
                printf("opcao invalida!\n");
            }

    }

    return 0;
}

void imprime_fila(aluno p, alu elem)
{
    if(fila_vazia(p) == 1){

        printf("\n --Fila Vazia--\n");
        return;
    }
    printf("\nFila:\n");

    aluno aux = cria_fila();

    while (fila_vazia(p) == 0)
    {
        remove_ini (p, &elem);

        printf("Matricula: %ld\n", elem.matricula);
        printf("Nome: %s\n", elem.nome);
        printf("Nota: %.2f\n", elem.nota);

        if (elem.nota >= 60)
            printf("Aprovado\n");
        else
            printf("Reprovado\n");

        insere_fim(aux, elem);
        printf ("\n\n");
    }
     while(fila_vazia(aux)==0)
    {
        remove_ini(aux, &elem);
        insere_fim(p, elem);
    }

}
