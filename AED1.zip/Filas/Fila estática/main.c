#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "head.h"

#define max 20
#define max2 10

struct Aluno{

  alu cadastro[max2];
  int ini, fim;
};

aluno cria_fila ()
{
    aluno p = (aluno)malloc(sizeof(struct Aluno));
    if (p != NULL){
        p -> ini = 0;
        p -> fim = 0;
    }

    return p;
}

int fila_vazia (aluno p)
{
    if (p -> ini == p -> fim)
        return 1;
    else
        return 0;
}

int fila_cheia (aluno p)
{
    if (p -> ini == (p -> fim + 1) % max)
        return 1;
    else
        return 0;
}

int insere_fim (aluno p, alu elem)
{

    if (fila_cheia(p) == 1)
        return 0;

    p -> cadastro[p -> fim] = elem;

    p -> fim = (p -> fim + 1) % max2;

    return 1;
}

int remove_ini (aluno p, alu *elem)
{
    if (fila_vazia(p) == 1)
        return 0;

     *elem = p -> cadastro[p -> ini];
     p -> ini = (p -> ini + 1) % max2;

     return 1;
}

int tamanho_fila (aluno p){

    if(p == NULL)
        return -1;

    return (p -> fim) - (p -> ini);
}

int esvazia_fila (aluno p)
{

    if (p == NULL)
        return -1;

    p -> fim = 0;
    p -> ini = 0;

    return 1;

}

int apaga_fila (aluno *p)
{

    if (*p == NULL)
        return 0;

    free (*p);
    *p = NULL;

    return 1;
}













