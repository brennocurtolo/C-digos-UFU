#include <stdio.h>
#include "complexos.h"

int main()
{

    cpx comp1, comp2;
    double a, b;
    cpx ca, cb, cc, subtracao, r;

    printf ("Criacao de um numero complexo:\n");

    printf ("Digite um real e um imaginario:\n");
    scanf ("%lf %lf", &a, &b);

    ca = cria_nro (a, b);
    get_nro(ca);

    printf ("Digite um real e um imaginario:\n");
    scanf ("%lf %lf", &a, &b);

    cb = cria_nro (a, b);
    get_nro(cb);

    printf ("Digite um real e um imaginario:\n");
    scanf ("%lf %lf", &a, &b);

    cc = cria_nro (a, b);
    get_nro(cc);

    subtracao = sub(ca, cc);
    r = mult(subtracao, cb);

    printf("O resultado de (C1 - C3) X C2 eh = ");
    get_nro(r);

    return 0;
}
