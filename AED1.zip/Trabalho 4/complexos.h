#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

typedef struct complexo *cpx;

cpx cria_nro(double a, double b);

double set_nro (double a, double b, cpx complexo);

cpx get_nro (cpx complexo);

int libera_nro (cpx *complexo);

cpx soma(cpx a, cpx b);

cpx sub(cpx a, cpx b);

cpx mult (cpx a, cpx b);





#endif // MAIN_H_INCLUDED
