#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "complexos.h"

struct complexo {
    double a;
    double b;
};

typedef struct complexo *cpx;

cpx cria_nro(double a, double b){
    cpx complexo = (cpx) malloc(sizeof(struct complexo));
    if (complexo != NULL){
        complexo -> a = a;
        complexo -> b = b;
    }
}

double set_nro (double a, double b, cpx complexo){
     if(complexo == NULL){
        return -1;
    }
    complexo->a = a;
    complexo->b = b;
    return 1;
}

cpx get_nro (cpx ab){
    if (ab == NULL){
        return 0;
    }
    printf("%lf + %lfi\n", ab -> a, ab -> b);
}

int libera_nro (cpx* ab){
    if (ab == NULL){
        return 0;
    }
    free(ab);
    *ab = NULL;
    return 1;
}

cpx soma(cpx comp1, cpx comp2){
    if (comp1 == NULL)
        return 0;

    if (comp2 == NULL)
        return 0;

    return cria_nro (comp1 -> a + comp2 -> a, comp1 -> b + comp2 -> b);
}

cpx sub(cpx comp1, cpx comp2){
    if (comp1 == NULL)
        return 0;

    if (comp2 == NULL)
        return 0;
    return cria_nro (comp1 -> a - comp2 -> a, comp1 -> b - comp2 -> b);
}

cpx mult (cpx comp1, cpx comp2){
     if (comp1 == NULL)
        return 0;

    if (comp2 == NULL)
        return 0;
    return cria_nro (comp1 -> a * comp2 -> a - comp1 -> b * comp2 -> b, comp1 -> a * comp2 -> b + comp2 -> a * comp1 -> b);
}
