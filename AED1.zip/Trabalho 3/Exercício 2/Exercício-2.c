#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

struct cadastro{
    char nome[20];
    int volume;
    float preco;
};

void menu (struct cadastro bebidas[]);
void *inserir (struct cadastro **bebidas[]);
void *imprimir (struct cadastro *bebidas[]);
void sair ();


int main()
{
    struct cadastro *bebidas[20];

    for(int i = 0; i < 20; i++)
    {
        bebidas[i] = NULL;
    }

    menu (bebidas);

    return 0;
}

void *inserir (struct cadastro **bebidas[]){

    int i, n;

    system ("cls");

    if(bebidas[19]!= NULL){
        printf("Tabela cheia!\n");

    }
    else{
    for(int i=0; i<20;i++)
    {
        if(bebidas[i] == NULL)
        {
            n = i;
            break;
        }
    }

    struct cadastro *bebidass;
    bebidass = (struct cadastro *)malloc(sizeof(struct cadastro));

        printf ("Nome da bebida:\n");
        scanf ("%s", bebidass->nome);

        printf ("Volume em (ml):\n");
        scanf ("%d", &bebidass->volume);

        printf ("Preco:\n");
        scanf ("%f", &bebidass->preco);

        bebidas[n]= bebidass;
        menu (bebidas);
    }

}

void *apagar (struct cadastro **bebidas[]){

    if(bebidas[0]== NULL){
        printf("Tabela ja vazia!\n");
    }

    else{
    int n;
    for(int i=0; i<20;i++)
    {

        if(bebidas[i] == NULL)
        {
            n = i-1;
            break;
        }

    }

    printf("Bebida %d excluida!\n", n);
    bebidas[n] = NULL;
    }


}

void *imprimir (struct cadastro *bebidas[]){

    char escolha;

    system ("cls");

    for (int i = 0; i < 20; i++){

        if(bebidas[i]!=NULL){
            printf ("Nome   Volume   Preco\n");
            printf (" %s     %d ml   %.2f\n", bebidas[i]->nome, bebidas[i]->volume, bebidas[i]->preco);
        }
    }
    getch ();
    main (bebidas);


}

void sair (){

    system ("exit");

}

void menu (struct cadastro bebidas[]){

    int opcao;

    system ("cls");

    printf("Escolha uma opcao:\n");

    printf("[1] - Inserir bebida na tabela:\n");
    printf("[2] - Apagar ultimo registro da tabela:\n");
    printf("[3] - Imprimir tabela:\n");
    printf("[4] - Sair:\n");

    scanf ("%d", &opcao);


    switch (opcao){
        case 1:
            inserir(bebidas);
            break;

        case 2:
            apagar(bebidas);
            break;

        case 3:
            imprimir(bebidas);
            break;

        case 4:
            sair();
            break;

        default:
            system ("exit");
    }

}








