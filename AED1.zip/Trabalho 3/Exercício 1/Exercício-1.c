#include <stdio.h>
#include <stdlib.h>

struct dados{
    int codigo;
    char nome[30];
    double media;
    int faltas;
};

struct dados *aloca (int quantidade);

void turma (int quantidade, struct dados *alunos);

void selection (int quantidade, struct dados *alunos);

void imprime (int quantidade, struct dados *alunos);

int main()
{
    int quantidade;

    printf ("Informe a quantidade de alunos:\n");
    scanf ("%d", &quantidade);

    struct dados *alunos;

    alunos = aloca (quantidade);

    turma (quantidade, alunos);

    selection (quantidade, alunos);

    imprime (quantidade, alunos);

    return 0;
}

struct dados *aloca (int quantidade){

    struct dados *p;

    p = (struct dados *) malloc(quantidade * sizeof(struct dados));

    return p;
}

void turma (int quantidade, struct dados *alunos){

    int i;

    for (i = 0; i < quantidade; i++){

        printf ("Digite o codigo do aluno:\n");
        scanf ("%d", &alunos[i].codigo);

        printf ("Digite o nome do aluno:\n");
        scanf ("%s", alunos[i].nome);

        printf ("Digite a media do aluno:\n");
        scanf ("%lf", &alunos[i].media);

        printf ("Digite as faltas do aluno:\n");
        scanf ("%d", &alunos[i].faltas);

    }

}

void selection (int quantidade, struct dados *alunos){

    int i, troca;
    struct dados copia;

    do{
        troca = 0;
        for (i = 0; i < quantidade - 1; i++){
            if (alunos[i].codigo > alunos[i + 1].codigo){
                copia = alunos[i];
                alunos[i] = alunos[i + 1];
                alunos[i + 1] = copia;
                troca = 1;
            }
        }
    }while (troca);

}

void imprime (int quantidade, struct dados *alunos){

    for (int i = 0; i < quantidade; i++){
        printf ("\n%d\n", alunos[i].codigo);
        printf ("%s\n", alunos[i].nome);
        printf ("%.2lf\n", alunos[i].media);
        printf ("%d\n", alunos[i].faltas);
    }

}






