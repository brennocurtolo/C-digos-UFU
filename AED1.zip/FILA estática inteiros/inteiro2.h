#ifndef INTEIRO2_H_INCLUDED
#define INTEIRO2_H_INCLUDED

typedef struct Fila *fila;

fila cria_fila ();

int fila_vazia (fila p);

int fila_cheia (fila p);

int insere_fim (fila f, int elem);

int remove_ini (fila f, int *elem);

int esvazia_fila (fila p);

int apaga_fila (fila p);

int get_fim(fila f, int elem);

#endif // INTEIRO2_H_INCLUDED
