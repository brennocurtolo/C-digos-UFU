#include <stdio.h>
#include <stdlib.h>
#include "inteiro2.h"
#define max 20

struct Fila{

  int no[max];
  int ini, fim;
};

fila cria_fila ()
{
    fila f = (fila)malloc(sizeof(struct Fila));
    if (f != NULL){
        f -> ini = 0;
        f -> fim = 0;
    }

    return f;
}

int fila_vazia (fila f)
{
    if (f -> ini == f -> fim)
        return 1;
    else
        return 0;
}

int fila_cheia (fila f)
{
    if (f -> ini == (f -> fim + 1) % max)
        return 1;
    else
        return 0;
}

int insere_fim (fila f, int elem)
{

    if (fila_cheia(f) == 1)
        return 0;

    f -> no[f -> fim] = elem;
    f -> fim = (f -> fim + 1) % max;

    return 1;
}

int remove_ini (fila f, int *elem)
{
    if (fila_vazia(f) == 1)
        return 0;

     *elem = f -> no[f -> ini];
     f -> ini = (f -> ini + 1) % max;

     return 1;
}

int esvazia_fila (fila f)
{
    if (fila_vazia(f) == 1)
        return 0;

    while ((f -> ini) != (f-> fim)){
        f -> ini = (f -> ini + 1) % max;
    }

    f -> ini = f -> fim + 1;

    return 1;

}

int apaga_fila (fila f)
{

    f = NULL;
    free (f);

    return 1;

}

int get_fim(fila f, int elem)
{
    if (fila_vazia(f) == 1)
        return 0;

    elem = f -> no[f -> fim];
    return 1;
}
