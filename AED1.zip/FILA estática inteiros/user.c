#include <stdio.h>
#include <stdlib.h>
#include "inteiro2.h"
#define max 20

void imprime_fim(fila f, int elem);
void imprime_fila(fila f, int elem);

int main()
{

    fila f = NULL;

    int ativo = 0;
    int n;
    int no[max];
    int elem;

    while(ativo != 1){

        printf("--------------------------------------------\n");
        printf("--Fila--\n");
        printf("\n 1 - Criar Fila\n");
        printf(" 2 - Inserir elemento na Fila\n");
        printf(" 3 - Remover ultimo elemento da Fila\n");
        printf(" 4 - Imprimir Fila\n");
        printf(" 5 - Imprimir topo da Fila\n");
        printf(" 6 - Limpar Fila\n");
        printf(" 7 - Apagar Fila\n");
        printf(" 8 - Verificar tamanho da Fila\n");
        printf(" 9 - Sair\n");
        printf("--------------------------------------------\n");

        scanf("%d", &n);
        setbuf(stdin, NULL);

        switch(n){

            case 1:
                f = cria_fila();
                if(f == NULL)
                    printf("A fila nao foi criada\n");
                else
                    printf("A fila foi criada com sucesso\n");

                break;

            case 2:
                printf("Insira o valor: ");
                scanf("%d", &no[max]);

                if(insere_fim(f, elem) == 0)
                    printf("Nao foi possivel adicionar.\n");
                else
                    printf("Valor %d incluido.\n", no[max]);

                break;

            case 3:

                if(remove_ini(f, &elem) == 0)
                    printf("Fila vazia.\n");
                else
                    printf("O elemento %d foi removido.\n", elem);

                break;

            case 4:
                if(f != NULL)
                    imprime_fila(f, elem);
                else
                    printf("Nao foi possivel imprimir.\n");

                break;

            case 5:
                if(f != NULL)
                    imprime_fim(f, elem);
                else
                    printf("Nao foi possivel imprimir\n");

                break;

            case 6:
                if(esvazia_fila(f) == 0)
                    printf("A Fila ja esta vazia.\n");
                else
                    printf("Fila esvaziada.\n");

                break;

            case 7:
                apaga_fila(f);
                printf("Fila apagada.\n");

                break;

           /* case 8:
                if (tamanho_fila(f) >= 0)
                    printf("A Fila tem tamanho igual a %d\n", tamanho_fila(p));
                else
                    printf("Fila invalida\n");

                break;

*/
            case 9:
                ativo = 1;
                break;
            default:
                printf("opcao invalida!\n");
            }

    }

    return 0;
}

void imprime_fila(fila f, int elem){

    int no[max];
    if(fila_vazia(f) == 1){

        printf("\n --A Fila esta Vazia--\n");
        return;
    }

    printf("\nFila:\n");

    fila y = cria_fila();
    while (fila_vazia(f) == 0)
    {
        remove_ini (f, &elem);
        printf(" %d\n", no[max]);
        insere_fim(y, elem);
    }
    while(fila_vazia(y)==0)
    {
        remove_ini(y, &elem);
        insere_fim(f, elem);
    }
}

void imprime_fim(fila f, int elem){


    if(fila_vazia(f) == 1){

        printf("\n --A Fila esta Vazia--\n");
        return;
    }

    if ((get_fim(f, elem) == 1))
    printf("%d\n", elem);
}


